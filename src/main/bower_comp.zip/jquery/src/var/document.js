define( function() {
	return window.document;
} );
